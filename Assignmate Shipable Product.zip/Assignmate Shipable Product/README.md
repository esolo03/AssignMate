# AssignMate  
**Academic Success At Your Fingertips**

AssignMate is a simple, user-friendly web application that helps students and teachers manage assignments and academic tasks efficiently.


##  Development Info
- Built with: **HTML, CSS, JavaScript**
- IDE: **Visual Studio Code**
- Version Control: **Git & GitHub**
- Repository: [https://github.com/esolo03/AssignMate](https://github.com/esolo03/AssignMate)



